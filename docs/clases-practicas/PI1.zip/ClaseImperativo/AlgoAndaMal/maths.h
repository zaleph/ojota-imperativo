#ifndef MATHS_H_INCLUDED
#define MATHS_H_INCLUDED

int fibonacci(const int);
int valorAbsoluto(int);
bool signoYCambiar(int&);
bool primo(const int x);
int otraFuncion();

#endif // MATHS_H_INCLUDED
