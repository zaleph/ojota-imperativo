#ifndef AUXILIARES_H_INCLUDED
#define AUXILIARES_H_INCLUDED

int cuadruple(int a);

#endif // AUXILIARES_H_INCLUDED
