#ifndef AUXILIARES_H_INCLUDED
#define AUXILIARES_H_INCLUDED

int sumax(int x);
void swapA(int x, int y);
void swapB(int &x, int &y);
void swapC(int &x, int &y);

#endif // AUXILIARES_H_INCLUDED
